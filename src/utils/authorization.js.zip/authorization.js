import hexMD5 from 'js-md5'

/**
 * 接口加密
 * 参数 type==1用户级加密 type==0 系统级加密
 * type==0 : token = 固定值
 * type==1 : token = 用户token 存储于localStorage字段=userToken id=用户id字段=userId
 */

export function authorizationVue(type) {
  // const id = localStorage.getItem('userId')
  const id = 7129
  const timestamp = Date.parse(new Date()).toString()
  let token = ''
  let authorizationStr = ''
  switch (type) {
    case 0:
      authorizationStr = 'Sys 2001.'
      token = 'token1'
      break
    case 1:
      authorizationStr = 'Bearer ' + id + '.'
      // token = localStorage.getItem('userToken')
      token = '1c9280ca54e231d78dbdd591717cb8fe'
      break
  }

  const encryptStr = authorizationStr + timestamp + '.' + md5(type, token, timestamp)

  return encryptStr
}
function md5(type, token, timestamp) {
  let str = ''
  const num = '2001'
  switch (type) {
    case 0:
      str = hexMD5(num + '.' + timestamp + '.' + token)
      break
    case 1:
      str = token
      break
  }
  return str
}
